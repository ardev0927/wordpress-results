<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage modus
 * @since modus 1.0
 */ 
?>

<div class="row">
	<?php while (have_posts()) : the_post(); ?>
		<div class="col-xs-12 col-sm-6 col-md-4">
			<div class="item-portfolio">
				<a href="<?php the_permalink();?>"><?php  the_post_thumbnail( 'full' );?></a>
				<div class="box-holder">
					<div class="box-holder-content">
						<a href="<?php the_permalink();?>"><span><?php the_title();?></span></a>
						<ul class="cat_portfolio">
							<li>
								<?php
								$cate = get_the_term_list($post->ID, 'portfolio_cat', '', ', ');
								if (!empty($cate)) {
									echo get_the_term_list($post->ID, 'portfolio_cat', '', ', ', '');
								}
								?>
							</li>
						</ul>
						<a class="md-linkto" href="<?php the_permalink();?>"><i class="Pe-icon-7-stroke-link"></i></a>
					</div>
				</div>
			</div>
		</div>
	<?php endwhile; ?>
	<div class="col-xs-12 col-sm-12 col-md-12">
		<?php 
			$older_posts = esc_html__('Older posts','modus');
			$newer_posts = esc_html__('Newer posts','modus');
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => '<i class="Pe-icon-7-stroke-angle-left"></i> '. $newer_posts .'',
				'next_text'          => ''. $older_posts .'<i class="Pe-icon-7-stroke-angle-right"></i>',
				'before_page_number' => '<span class="meta-nav screen-reader-text"></span>',
			) );
		?>
	</div>
</div>
