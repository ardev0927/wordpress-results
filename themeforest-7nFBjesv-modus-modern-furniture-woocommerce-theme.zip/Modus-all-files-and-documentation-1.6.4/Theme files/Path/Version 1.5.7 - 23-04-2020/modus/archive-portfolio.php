<?php
get_header();
$modus_config = modus_settings();
$modus_layout_single_port = '';
$show_title = 'show';
$page_show_breadcrumb = 'show'; 

?>
	<div id="primaryzz" class="content-area">
		<main id="main" class="blog site-main" role="main">
			<?php if($show_title == 'show' && $page_show_breadcrumb == 'show' ):?>
				<div class="breadcrumb-container">
					<div class="bottom-breadcrumb">
						<div class=" container">
							<?php if($show_title == 'show'){ ?>
							<div class="page-title">
								<h2><?php echo get_the_title(); ?></h2>
							</div>
							<?php } ?>			
							<?php if ( $page_show_breadcrumb == 'show' ) { ?>
							<div class="bread-crumb">
								<?php echo modus_breadcrumbs(); ?>
							</div> 
							<?php } ?>
						</div>
					</div>	
				</div>	
			<?php endif;?>			
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<?php if (have_posts()): ?>
							<?php get_template_part('template-parts/content', 'portfolio'); ?>
						<?php else: ?>
							<?php get_template_part('content', 'none'); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
<?php get_footer(); ?>
