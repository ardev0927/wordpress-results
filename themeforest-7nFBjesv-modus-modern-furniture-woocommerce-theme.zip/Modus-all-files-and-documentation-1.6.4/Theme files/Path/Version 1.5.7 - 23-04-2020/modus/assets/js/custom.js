(function ($) {
    "use strict";
    shortcode_tab('.modus-timeline');
    list_category('.modus-product-category .list-category');
    shortcode_content_container();
    modus_StickyMenu(); 
    // Sticky Menu
    function modus_StickyMenu() {
        var  mn = $("#masthead");
        var mns = "is-sticky";
        var hdr = $('header').height();
        $(window).scroll(function() {
            if(modus_params.modus_sticky_menu == 'show') {
                if( $(this).scrollTop() > hdr ) {
                    mn.addClass(mns);
                } else {
                    mn.removeClass(mns);
                }
            }
        });
    }
    jQuery(".modus-tab-loadmore .nav-tab .select_title").each(function() {
        jQuery(this).on( "click", function(t) {
            t.preventDefault();
            var e = jQuery(this).parent(".mobile");
            jQuery(this).toggleClass("active");
            e.find(".select_list").toggleClass("active")
        })
    });
    jQuery( '.modus-product-tab .nav-tab ul li a' ).each(function(e){
        var _this = jQuery(this);
        _this.on( "click", function(e) {
            e.preventDefault();
            jQuery(".modus-tab-loadmore .nav-tab .select_title li a").html(_this.html());
            jQuery(".modus-tab-loadmore .nav-tab .select_list").removeClass("active");
            _this.closest( '.modus-product-tab' ).find(' .nav-tab ul li a').removeClass('active');
            _this.closest( '.modus-product-tab' ).find(' .tabs-content .product-tab').removeClass('active');
            _this.addClass('active');
            var selector = _this.attr('data-filter');
            _this.closest( '.modus-product-tab' ).find('.tabs-content .'+selector).addClass('active');
        })
    })
    jQuery('.footer-v8 .mc4wp-form-fields input[type="email"]').attr('placeholder','e-mail');

    jQuery('.btn-responsive-nav').on( "click", function() {
        jQuery('.menu-mobile, .main-nav').toggleClass('active');
    });
    jQuery('.close-menu, .header-v10 .widget-close').on( "click", function() {
        jQuery('.main-nav, .header-v10 .main-nav').removeClass('active');
        jQuery('body').removeClass('mobile_menu_active');
    });
    if ($(window).width() > 991){
        var wow = new WOW({
            mobile: false
        });
        wow.init();
    }
    if(jQuery('.au_fadeIn').length){
        if (jQuery(window).width() > 991){
            jQuery(window).scroll(function() {
                var wS = jQuery(window).scrollTop();
                var wH = jQuery(window).height();
                var opset_height = wS+wH;
                jQuery('.au_fadeIn').each(function(){
                    var shortcodetitle_height = jQuery(this).offset().top;
                    if(opset_height > shortcodetitle_height){
                        jQuery(this).addClass('animated fadeIn');
                    }
                });
            });
        }else{
            jQuery('.au_fadeIn').each(function(){
                jQuery(this).addClass('animated fadeIn');
            });
        }
    }
    /*Tabs*/
    function shortcode_tab( element ){
        jQuery( element+' .nav-tab ul li a' ).each(function(e){
            var _this = jQuery(this);
            _this.on( "click", function(e) {
                e.preventDefault();
                _this.closest( element ).find(' .nav-tab ul li a').removeClass('active');
                _this.closest( element ).find(' .tabs-content .product-tab').removeClass('active');
                _this.addClass('active');
                var selector = _this.attr('data-filter');
                _this.closest( element ).find('.tabs-content .'+ selector).addClass('active');
            })
        })
    }
    function list_category( element ){
        jQuery( element+' nav ul li' ).each(function(){
            var _this = jQuery(this);
            _this.on( "click", function(e) {
                e.preventDefault();
                _this.closest( element ).find(' nav ul li').removeClass('active');
                _this.closest( element ).find(' .description-cat .des-cat').removeClass('active');
                _this.addClass('active');
                var selector = _this.attr('data-filter');
                _this.closest( element ).find('.description-cat .'+selector).addClass('active');
            })
        })
    }
    // Submenu hover left

    $('.main-navigation div > ul > li:not(.megamenu)').mouseover(function(){
        var wapoMainWindowWidth = $(window).width();
        // checks if third level menu exist
        var subMenuExist = $(this).children('.sub-menu').length;
        if( subMenuExist > 0){
            var subMenuWidth = $(this).children('.sub-menu').width();
            var subMenuOffset = $(this).children('.sub-menu').parent().offset().left + subMenuWidth;
            // if sub menu is off screen, give new position
            if((subMenuOffset + subMenuWidth) > wapoMainWindowWidth){
                var newSubMenuPosition = subMenuWidth;
                $(this).addClass('left_side_menu');
            }else{
                var newSubMenuPosition = subMenuWidth;
                $(this).removeClass('left_side_menu');
            }
        }
    });

    /*blog_ajax_load_more*/
    $('.modus-blog .modus_ajax_load_more, .modus-product .modus_ajax_load_more, .modus-product-tab .modus_ajax_load_more, .modus-portfolio-tab .modus_ajax_load_more').on( 'click', function(e) {
        e.preventDefault();
        var container = $('.modus-blog .blog-list');
        var container_portfolio = $('.active .modus-portfolio-more');
        var container_product = $('.active .modus-product-more');

        var _this = $(this), btn_html = $(this).html();
        var modus_action = 'modus_ajax_load_more';
        var modus_layout = _this.data('layout');
        var modus_type_list = _this.data('type_list');
        var modus_object=_this.data();
        var modus_data = "&action="+modus_action;
        $.each(modus_object, function(index, value) {
            modus_data = modus_data + "&modus_"+index+"="+value;
        });
        var modus_currentpage = _this.data('currentpage');
        var modus_maxpage = _this.data('maxpage');
        $.ajax({
            url: modus_ajax_load_more.ajaxurl,
            type: 'post',
            data:modus_data,
            beforeSend: function() {
                _this.css({'min-width':_this.innerWidth(),'min-height':_this.innerHeight()})
                _this.html('<i class="fa fa-spinner"></i>');
            },
            success: function( html ) {
                if ( html != '' ) {
                    if ( modus_layout == 'list' ){
                        container.append(html);
                    };
                    if( modus_layout == "feature-product-more"){
                        container_product.append(html);
                    }
                    if( modus_layout == "producttab-loadmore"){
                        container_product.append(html);
                    }
                    container_portfolio.append(html);
                }

                if ( modus_currentpage + 1 == modus_maxpage ) {
                    _this.remove();
                }
                else {
                    _this.data('currentpage', modus_currentpage + 1 );
                    _this.html( btn_html );
                }
            },
            complete: function() {
            },
            error: function( request, status, error ) {
                console.log( request.responseText );
            }
        });
    });
    if(jQuery('.category_dropdown ul.dropdown-menu li').length){
        jQuery('.category_dropdown ul.dropdown-menu li').each(function(){
            jQuery(this).on( "click", function() {
                jQuery(this).closest('.category_dropdown').find('.dropdown-toggle').html('<span>'+jQuery(this).text()+'</span><i class="fa fa-angle-down"></i>');
                jQuery(this).closest('form.woocommerce-product-search').find('input[name="product_cat"]').val(jQuery(this).data('val'));
                jQuery(this).closest('.category_dropdown').find('.dropdown-toggle li').removeClass('active');
                jQuery(this).addClass('active');
            });
        });
    }
    /*********** Search ajax **********/
    jQuery('.woocommerce-product-search').each(function(){
        var $_this = jQuery(this);
        var $_input_search = jQuery(this).find('.search-field');
        var $_search_result = jQuery(this).find('.auto_ajax_search');
        var myVar =false;
        $_input_search.keyup(function(e){
            $_search_result.addClass('loading');
            $_search_result.html('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>');
            var search_val = $_input_search.val();
            var search_cat = $_this.find('input[name="product_cat"]').val();
            if(search_val.length > 2){
                myVar = setTimeout(
                    function(){
                        jQuery.ajax({
                            url: modus_ajax_product.ajaxurl,
                            type: "post",
                            data: {
                                action: 'au_ajax_search_product',
                                s: search_val,
                                product_cat: search_cat
                            },
                            complete: function(response){
                                $_search_result.addClass('active');
                                $_search_result.removeClass('loading');
                            },
                            success: function(response){
                                $_search_result.html(response);
                            }
                        });
                    },
                    500
                );
            }else{
                if(search_val == ''){
                    $_search_result.removeClass('loading');
                    $_search_result.html('');
                }
                $_search_result.removeClass('active');
                clearTimeout(myVar);
            }
        }).keyup(function(e){
            $_search_result.removeClass('active');
            $_search_result.html('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>');
            clearTimeout(myVar);
            var search_val = $_input_search.val();
            var search_cat = $_this.find('input[name="product_cat"]').val();
            if(search_val.length > 2){
                myVar = setTimeout(
                    function(){
                        jQuery.ajax({
                            url: modus_ajax_product.ajaxurl,
                            type: "post",
                            data: {
                                action: 'au_ajax_search_product',
                                s: search_val,
                                product_cat: search_cat
                            },
                            complete: function(response){
                                $_search_result.addClass('active');
                                $_search_result.removeClass('loading');
                            },
                            success: function(response){
                                $_search_result.html(response);
                            }
                        });
                    },
                    500
                );
            }else{
                if(search_val == ''){
                    $_search_result.removeClass('loading');
                    $_search_result.html('');
                }
                clearTimeout(myVar);
                $_search_result.removeClass('active');
            }
        });
    });
    /** Sub menu **/
    if(jQuery('.footer .widget_nav_menu h3.widget-title').length){
        jQuery('.footer .widget_nav_menu h3.widget-title').toggle(function() {
                jQuery(this).closest('.widget_nav_menu').find('.menu').fadeIn("slow");
            },
            function() {
                jQuery(this).closest('.widget_nav_menu').find('.menu').fadeOut("slow");
            });
    }
    if(jQuery('.menu-button').length){
        jQuery('.menu-button button').on( "click", function() {
            jQuery('body').addClass('mobile_menu_active');
            jQuery('.main-nav').addClass('active');
        });
        jQuery('.close-menu').on( "click", function() {
            jQuery('body').removeClass('mobile_menu_active');
            jQuery('.main-nav').removeClass('active');
        });
    }
    if(jQuery('.menu_departments').length){
        $('.department_click').on( "click", function() {
            jQuery(this).closest('.menu_departments').find('.menu-departments-wrap').toggleClass('active');
        });
    };
    $("li.menu-item-has-children > span.arrow").on( "click", function(e) {
        var $_this = $(this);
        var $_parrent1 = $(this).closest('li.menu-item-has-children');
        var $_parrent2 = $_parrent1.closest('li.menu-item-has-children');
        var $_parrent3 = $_parrent2.closest('li.menu-item-has-children');
        $('li.menu-item-has-children').each(function(){
            if ( $(this).find($_this).length ) {  return true; }
            $(this).removeClass("active");
            $(this).find(' > ul.sub-menu').slideUp('slow');
        });
        $_this.parent().toggleClass('active');
        $_this.parent('li').find(' > ul.sub-menu').slideToggle('slow');
    });

    jQuery('.vc_tta-tab').on('click', function(event) {
        if(jQuery(this).closest('.vc_tta-tabs').find('.slide-product')){
            jQuery(this).find('.flexslider').resize();
            jQuery(this).closest('.vc_tta-tabs').find('.slide-product').resize();
        }
    });
    $( document ).ajaxComplete(function( event,request, settings ){
        if($('#cart_number').length){
            $('.modus-cart .cart-num').html($('#cart_number').val());
            $('.modus-cart .modus_total').html($('#cart_price').val());
        }
        if($('#cart_price').length){
            $('.modus-cart .modus_total').html($('#cart_price').val());
        }
        $('body').removeClass('loading');
    });
    $('.modus-cart button').on( "click", function() {
        $(this).closest('.mini-cart').toggleClass('active');
    });
    $('.widget-close').on( "click", function(e) {
        e.preventDefault();
        $(this).closest('.mini-cart').toggleClass('active');
    });
    $('.modus-close-cart').on( "click", function() {
        $(this).closest('.mini-cart').toggleClass('active');
    });
    $(document).on('click', '.mini_cart_item a.remove', function (e){
        e.preventDefault();

        var product_id = $(this).attr("data-product_id"),
            cart_item_key = $(this).attr("data-cart_item_key"),
            product_container = $(this).parents('.mini_cart_item');

        // Add loader
        product_container.block({
            message: null,
            overlayCSS: {
                cursor: 'none'
            }
        });

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: wc_add_to_cart_params.ajax_url,
            data: {
                action: "product_remove",
                product_id: product_id,
                cart_item_key: cart_item_key
            },
            success: function(response) {
                if ( ! response || response.error )
                    return;
                var fragments = response.fragments;
                if ( fragments ) {
                    $.each( fragments, function( key, value ) {
                        $( key ).replaceWith( value );
                    });
                }
            }
        });
    });
    $('.product-categories >li.cat-parent').on( "click", function(e) {
        // e.preventDefault();
        $(this).find('.children').toggle('slow');
    });
    /**page shop**/
    jQuery('.list-view-as li').each(function(){
        jQuery(this).find('a').on( "click", function(e) {
            e.preventDefault();
            var data_show = jQuery(this).data('layout');
            var data_column = jQuery(this).data('column');
            var current_grid = jQuery('.list-view-as li a.active').data('column');
            if(data_show == 'layout-grid'){
                jQuery('.products'+' .layout-grid').removeClass('column_'+current_grid);
                jQuery('.products'+' .'+ data_show).addClass('column_' +data_column);
                jQuery('.products').removeClass('list');
                jQuery('.products').addClass('grid');
            }else if(data_show == 'layout-list'){
                jQuery('.products'+' .layout-grid').removeClass('column_'+current_grid);
                jQuery('.products').removeClass('grid');
                jQuery('.products').addClass('list');
            }
            jQuery('.list-view-as li a').removeClass('active');
            jQuery(this).addClass('active');
            jQuery('.products').find('>div').removeClass('active');
            jQuery('.products'+' .'+ data_show).addClass('active').fadeIn("slow");
        });
    });
    jQuery('.select_title').each(function() {
        jQuery(this).on( "click", function(e) {
            e.preventDefault();
            var $_custom_select = jQuery(this).parent('.custom_select');
            $_custom_select.find('.select_list').toggleClass('active');
        });
    });
    jQuery('.soft-category .all').each(function() {
        jQuery(this).on( "click", function(e) {
            e.preventDefault();
            var $_custom_select = jQuery(this).parent('.soft-category');
            $_custom_select.find('.select-cateogry').toggleClass('active');
            $_custom_select.find('.select-default .orderby').toggleClass('active');
        });
    });

    /*Cart js*/
    var q = jQuery('.quantity');
    q.on('click','button',function(e){
        e.preventDefault();
        var self = jQuery(this),
            data = self.data('count'),
            i = self.parent().children('input'),
            val = i.val();
        if(data === "plus"){
            i.val(++val);
        }
        else{
            if(val == 1) return false;
            i.val(--val);
        }
        jQuery( document ).on(
            'change input',
            'div.woocommerce > form .cart_item :input',
            jQuery( 'div.woocommerce > form input[name="update_cart"]' ).prop( 'disabled', false ) );
    });
    jQuery('.department-menu li.page_item_has_children').append('<i class="fa fa-angle-down" aria-hidden="true"></i>');
    jQuery('.department-menu >li.page_item_has_children i').on( "click", function() {
        jQuery(this).toggleClass('fa-angle-up');
        jQuery(this).parent().find('>.children').toggleClass('show-sub');
    })
    jQuery('.sub-menu').before('<i class="fa fa-angle-down" aria-hidden="true"></i>');
    jQuery('.main-navigation .primary-menu >li.page_item_has_children i').on( "click", function() {
        jQuery(this).toggleClass('fa-angle-up');
        jQuery( this ).toggleClass( 'open' ).next( '.sub-menu' ).slideToggle();
		jQuery(this).toggleClass( 'open' ).next( '.megamenu_sub' ).slideToggle();
    });
    jQuery('.widget.widget_nav_menu .menu-item-has-children').append('<i class="fa fa-plus" aria-hidden="true"></i>');
    jQuery('.widget.widget_nav_menu .menu-item-has-children i').on( "click", function() {
        jQuery(this).toggleClass('fa-minus');
        jQuery(this).parent().find('>.sub-menu').toggleClass('show-sub');
    })
    if(jQuery('.modus-countdown').length){
        jQuery('.modus-countdown').each(function(){
            var $_this=jQuery(this);
            var $_future_date = $_this.find('#future_date_1');
            var settime = $_future_date .attr('data-endate');
            $_future_date .countdowntimer({
                dateAndTime : settime,
                size : "lg",
                regexpMatchFormat: "([0-9]{1,4}):([0-9]{1,4}):([0-9]{1,4}):([0-9]{1,4})",
                regexpReplaceWith: '<div class="countdown-section">' +
                    '<div class="countdown-number">$1</div>' +
                    '<div class="countdown-char">'+modus_params.modus_text_day+'</div>' +
                    '</div>' +
                    '<div class="countdown-section">' +
                    '<div class="countdown-number">$2</div>' +
                    '<div class="countdown-char">'+modus_params.modus_text_hour+'</div>' +
                    '</div>' +
                    '<div class="countdown-section">' +
                    '<div class="countdown-number">$3</div>' +
                    '<div class="countdown-char">'+modus_params.modus_text_min+'</div>' +
                    '</div>' +
                    '<div class="countdown-section">' +
                    '<div class="countdown-number">$4</div>' +
                    '<div class="countdown-char">'+modus_params.modus_text_sec+'</div>' +
                    '</div>'
            });
        });
    }

    jQuery('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav'
    });
    jQuery('.slider-nav').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: false,
        arrows: false,
        centerMode: false,
        focusOnSelect: true
    });
    $('.blog-gallery').slick({
        dots: false,
        nextArrow: '<button class="btn-next"><i class="fa fa-angle-right"></i></button>',
        prevArrow: '<button class="btn-prev"><i class="fa fa-angle-left"></i></button>',
        infinite: true,
        autoplay: false,
        autoplaySpeed: 2000,
        slidesToShow: 1,
        slidesToScroll: 1,
    });
    $('.instagram-decor .instagram-pics').slick({
      dots: false,
        nextArrow: '<button class="btn-next"><i class="fa fa-angle-right"></i></button>',
        prevArrow: '<button class="btn-prev"><i class="fa fa-angle-left"></i></button>',
      infinite: false,
      speed: 300,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
	
	$('.category-slide .cate-archive').slick({
      dots: false,
        nextArrow: '<button class="btn-next"><i class="fa fa-angle-right"></i></button>',
        prevArrow: '<button class="btn-prev"><i class="fa fa-angle-left"></i></button>',
		infinite: false,
		speed: 300,
		slidesToShow: 4,
		slidesToScroll: 1,
		responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
    function shortcode_content_container(){
        caculator_padding();
        jQuery(window).resize(function() {
            caculator_padding();
        });
        function caculator_padding(){
            jQuery( document ).ready( function($){
                if(jQuery('.container .content_left_container').length){
                    var $_left=jQuery('.container').offset().left + 15;
                    jQuery('.container .content_left_container > .wpb_column:first-child > .vc_column-inner').css('padding-left',$_left);
                }
                if(jQuery('.container .content_right_container').length){
                    var $_left=jQuery('.container').offset().left + 15;
                    jQuery('.container .content_right_container > .wpb_column:last-child > .vc_column-inner').css('padding-right',$_left);
                }
            });
        }
    }

    jQuery('.md-portfolio-tt li').on( "click", function(e) {
        e.preventDefault();
        jQuery('.md-portfolio-tt li').removeClass('active');
        jQuery(this).addClass('active');
        jQuery('.modus_portfolio_tab_content').removeClass('active');
        var selector_port = jQuery(this).find('a').attr('data-filter');
        jQuery(this).closest('.modus-portfolio-tab').find('.md-port .'+selector_port).addClass('active');
    });
    jQuery(document).ready(function(){
        jQuery('.custom-padding-pr-decor .modus-product-more .row').removeClass ("row") ;
        if(window.location.hash) {
            var hash = window.location.hash;
            jQuery('.modus-portfolio-tab li').removeClass('active');
            jQuery('.modus_portfolio_tab_content').removeClass('active');
            jQuery('.modus-portfolio-tab li').each(function(){
                var _this = jQuery(this);
                if(_this.find('a').attr('href') == hash){
                    _this.click();
                }
            });
        } else {
          // Fragment doesn't exist
        }
          
    });
    jQuery(document).ready(function(){
        /** wishlist ajax **/
        var auto_update_wishlist_count = function() {
            $.ajax({
                beforeSend: function () {
                },
                complete : function () {
                },
                data : {
                    action: 'auto_update_wishlist_count'
                },
                success : function (data) {
                    $('.wishlist-count').html(' '+data);
                },
                url: yith_wcwl_l10n.ajax_url
            });
        };
        $('body').on( 'added_to_wishlist removed_from_wishlist', auto_update_wishlist_count );

        if ( jQuery('#carousel').length ) {
            var $_width = (jQuery('#carousel').width()) /3;
            jQuery('#carousel').flexslider({
                animation: "slide",
                controlNav: false,
                animationLoop: false,
                slideshow: false,
                itemWidth: $_width,
                itemMargin: 0,
                asNavFor: '.woocommerce-product-gallery'
            });
        }

        jQuery('.btn-share').each(function(){
            var share_button = jQuery(this).find('a');
            var title = false;
            if(jQuery(this).hasClass('btn-addtocart')){
                share_button.addClass('modus-tltp');
                var title = share_button.text();
            }else{
                share_button.addClass('modus-tltp');
                if(share_button.attr('title')){
                    var title = share_button.attr('title');
                }
            }
            if(title){
                share_button.attr('title','');
                share_button.append('<div class ="modus-tltp-text">'+ title +'</div>');
            }
        });

        /* Fancybox */
        jQuery('[data-fancybox]').fancybox({
            protect: true,
            youtube : {
                controls : 0,
                showinfo : 0
            },
            vimeo : {
                color : 'f00'
            },
            iframe : {
                css : {
                    width : '600px'
                }
            }
        });
    });
    jQuery('.header-v10 .menu-bar').on( "click", function(e) {
        /* Act on the event */
        e.preventDefault();
        jQuery('.site-inner').toggleClass('active');
        jQuery('.main-nav').toggleClass('open');
        jQuery(this).find('i').toggleClass('pe-7f-menu').toggleClass('fa fa-close');

    });
    jQuery('.close-nav-button').on( "click", function(e) {
        /* Act on the event */
        e.preventDefault();
        jQuery('.main-nav').removeClass('open');
    });
    if($('.masonry-list').length){
        jQuery('.masonry-list').each(function(){
            jQuery(this).imagesLoaded().progress( function() {
                $('.masonry-list').isotope({
                    itemSelector: '.grid-item',
                    percentPosition: true,
                    masonry: {
                        columnWidth: '.grid-sizer'
                    }
                })
            });
        });
    }
    jQuery(".tab-b li").on( "click", function(t) {
        jQuery(".tab-b li, .box-tab .boxtab").removeClass("active"),
            jQuery(this).addClass("active");
        var e = jQuery(this).data("filter");
        jQuery(this).closest(".box-mobile").find(".box-tab ." + e).addClass("active")
    })
    // Add class IE
    var ms_ie = false;
    var ua = window.navigator.userAgent;
    var old_ie = ua.indexOf('MSIE ');
    var new_ie = ua.indexOf('Trident/');
    if ((old_ie > -1) || (new_ie > -1)) {
        ms_ie = true;
    }
    if ( ms_ie ) {
        jQuery('body').addClass('ie-11');
    }
})(jQuery);