<div class="<?php echo esc_attr(modus_header_fixed())?>">
<?php $modus_config = modus_settings(); ?>
	<div id="header_v8" class="header header-v8">
		<div class="header-fullwidth">
			<div class="header_wrap">
				<div class="row header-center">
					<div class="logo col-md-2 col-sm-8 col-xs-5">
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<a class="logo-page" href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php modus_logo(); ?>
							</a>
						<?php endif;?>
					</div>
					<div class="text-center col-md-8 col-sm-2 col-xs-7 ">
						<div class="line-1">
							<div class="main-nav">
								<div class="close-menu"><i class="fa fa-close"></i></div>
								<div class="main-navigation">
									<?php
										if ( $modus_config['header_8_menu'] != '' ){
											$menu_id = $modus_config['header_8_menu'];
										}else{
											$menu_id = '';
										}
										if ( $menu_id == '' ) :
											if ( has_nav_menu( 'primary' ) ) :
												wp_nav_menu( array(
													'theme_location' => 'primary',
													'menu_class'     => 'primary-menu',
												) );
											endif;
										else:
											wp_nav_menu( array(
												'menu'    => $menu_id,
												'title_li'          => '',
												'menu_class'        => 'primary-menu',
											) );
										endif;
									?>
								</div>
							</div>
						</div>
					</div>
					<div class="right col-md-2 col-sm-4 col-xs-7 text-right header-v8-mb"> 
						<div class="mini-cart">
							<div class="menu-button">
								<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
								<div class="close-menu"></div>
							</div>
							<?php if( isset($modus_config['header_8_account']) && $modus_config['header_8_account'] =='show'){?>
								<?php if (class_exists('Woocommerce')) { ?>
									<div class="inline user-guest"> 
											<a href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id')) ;?>"><i class="icon-user-1"></i></a>
										<?php if ( !is_user_logged_in() ) { ?>
											<div class="login-popup"> 
												<h3 class="login-title"><span><?php esc_html_e('Sign in','modus')?></span><a class="create-account-link" href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id'));?>"><?php esc_html_e('Create an Account','modus')?></a></h3> 
												<?php
													woocommerce_login_form(); 
												?>
											</div>  
										<?php } ?>
									</div>
								<?php } ?>
							<?php }?>
							<div class="inline icon-search">
								<div class="dropdown">
									<button class="dropdown-toggle" type="button" data-toggle="dropdown" >
										<i class="icon-search3"></i>
									</button>
									<div class="dropdown-menu">
										<div class="search-popup">
											<?php if(class_exists( 'WooCommerce' )): ?>
												<?php echo get_product_search_form();?>
											<?php else: ?>
												<?php echo get_search_form();?>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php if( isset($modus_config['header_8_cart']) && $modus_config['header_8_cart'] =='show'){?>
								<div class="inline right">
									<?php
										if(function_exists('modus_header_minicart')) modus_header_minicart();
									?>
								</div>
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- #header_v3-->
</div>
