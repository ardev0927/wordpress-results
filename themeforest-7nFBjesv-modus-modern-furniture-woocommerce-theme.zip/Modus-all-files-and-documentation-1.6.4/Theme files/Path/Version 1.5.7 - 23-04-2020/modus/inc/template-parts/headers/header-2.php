<div class="<?php echo esc_attr(modus_header_fixed()).esc_attr(modus_header_over())?>">
<?php 
$modus_config = modus_settings(); 
if( isset($modus_config['header_2_topbar_show']) && $modus_config['header_2_topbar_show'] =='show'){?>
	<div class="header-top header2-top">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-8 col-left">
				<ul class="nav-mail-tel">
					<?php if ( $modus_config['modus_mail'] != '' ) : ?><li><a href="mailto:<?php echo esc_attr($modus_config['modus_mail'])?>"><i class="icon-mail2"></i><?php echo esc_html($modus_config['modus_mail']); ?></a></li><?php endif; ?>
					<?php if ( $modus_config['modus_phone'] != '' ) : ?>
					<li><a href="callto:<?php echo esc_attr($modus_config['modus_phone'])?>"><i class="icon-phone"></i><?php echo esc_html($modus_config['modus_phone']); ?></a></li><?php endif; ?>
				</ul>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-4 col-right">
				<div class="mini-cart"> 
					<?php if( isset($modus_config['header_2_account']) && $modus_config['header_2_account'] =='show'){?>
						<div class="user-guest">
							<a href="<?php echo get_permalink( 10 );?>"><i class="icon-user-1"></i></a>
						</div>
					<?php } ?>
					<?php if( isset($modus_config['header_2_cart']) && $modus_config['header_2_cart'] =='show'){?>
						<?php
							if(function_exists('modus_header_minicart')) modus_header_minicart();
						?>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
	<div id="header_v2" class="header header-v2"> 
		<div class="header_wrap">
			<div class="row header-center">
				<div class="col-md-3 col-xs-4">
					<div class="logo align-left">
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php modus_logo(); ?>
							</a>
						<?php endif;?>
					</div>
				</div>
				<div class="col-md-9 col-xs-8 col-menu">
					<div class="menu-button"> 
						<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
					</div>
					<div class="close-menu"></div>
					<div class="main-nav">	
						<div class="close-menu"><i class="fa fa-close"></i></div>					
						<div class="main-navigation">
							<?php
								if ( $modus_config['header_2_menu'] != '' ){
									$menu_id = $modus_config['header_2_menu'];
								}else{
									$menu_id = '';
								}
								if ( $menu_id == '' ) :
									if ( has_nav_menu( 'primary' ) ) :
										wp_nav_menu( array(
											'theme_location' => 'primary',
											'menu_class'     => 'primary-menu',
										) );
									endif;
								else:
									wp_nav_menu( array(
										'menu'    => $menu_id,
										'title_li'          => '',
										'menu_class'        => 'primary-menu',
									) );
								endif;
							?>
						</div>
					</div>
					<div class="inline icon-search">
						<div class="dropdown">
							<button class="dropdown-toggle" type="button" data-toggle="dropdown" >
								<i class="icon-search3"></i>
							</button>
							<div class="dropdown-menu"> 
								<div class="search-popup">
									<?php if(class_exists( 'WooCommerce' )): ?>
										<?php echo get_product_search_form();?>
									<?php else: ?>
										<?php echo get_search_form();?>
									<?php endif; ?>
								</div> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- #header_v2-->
</div>
 